const LOGIN_1 = "Preço de 1 login"

const LOGIN_2 = "Preço de 2 login"

const LOGIN_3 = "Preço de 3 login"

const CLIENTE_ID = "Cliente ID Gerencianet"

const CLIENTE_SECRET = "Cliente Secret Gerencianet"

const CPF_USER = "CPF cadastrado na gerencianet"

const NOME = "Nome completo"

const CHAVE = "Chave pix gerencianet"

const LINK_SUPORTE = "wa.me/5573000000000"

const DOWLOAD = "Dowload do seu aplicativo"

const API_KEY = "API KEY dada por @Bruno_VPN ou @dark339754"

const DATABASE_URL = "DatabaseURL dada por @Bruno_VPN ou @dark339754"

const NUMERO = "5573000000000"


// NÃO MEXER ABAIXO

function _0x4a25(){const _0xb15584=['@c.us','log','Restarting\x20...','ENCANEIE\x20O\x20CÓDIGO\x20QR\x20PELO\x20SEU\x20WHATSAPP.','.sessao','get','186249JanbcX','puppeteer','user','33923860dJYPkm','4155SnScqs','MenuSSH/','body','sendMessage','--no-sandbox','WhatsappBot','28430ARjgGK','Net','message','./utilitarios/DatabaseUtil.js','9675270lywdAe','73096GLWQfs','qrcode-terminal','32tVaiSy','TesteSSH/','ready','BOT\x20VENDAS\x20FOI\x20ATIVADO\x20COM\x20SUCESSO\x20!!','CLIENT\x20DISCONNECTED\x20','Validade','firebase','./utilitarios/Navegation.js','245ktQnvR','set','./commands/info.js','getContact','CheckUser/','1608gfdtuz','substring','3221836cefDIu','--disable-setuid-sandbox','!up'];_0x4a25=function(){return _0xb15584;};return _0x4a25();}function _0x269e(_0x4d5b1a,_0x502da1){const _0x4a2505=_0x4a25();return _0x269e=function(_0x269ebc,_0x62d341){_0x269ebc=_0x269ebc-0x7d;let _0x49f102=_0x4a2505[_0x269ebc];return _0x49f102;},_0x269e(_0x4d5b1a,_0x502da1);}const _0x36a913=_0x269e;(function(_0x5e7cca,_0x13c790){const _0x669778=_0x269e,_0x898b54=_0x5e7cca();while(!![]){try{const _0x5a79b3=-parseInt(_0x669778(0x93))/0x1*(parseInt(_0x669778(0x9a))/0x2)+parseInt(_0x669778(0x89))/0x3+-parseInt(_0x669778(0x80))/0x4+parseInt(_0x669778(0x8d))/0x5*(-parseInt(_0x669778(0x7e))/0x6)+parseInt(_0x669778(0xa2))/0x7*(-parseInt(_0x669778(0x98))/0x8)+-parseInt(_0x669778(0x97))/0x9+parseInt(_0x669778(0x8c))/0xa;if(_0x5a79b3===_0x13c790)break;else _0x898b54['push'](_0x898b54['shift']());}catch(_0x1acb7d){_0x898b54['push'](_0x898b54['shift']());}}}(_0x4a25,0x8cc55));const {Client,LocalAuth}=require('whatsapp-web.js'),puppeteer=require(_0x36a913(0x8a)),qrcode=require(_0x36a913(0x99)),firebase=require(_0x36a913(0xa0)),GerenciaPix=require('./utilitarios/GerenciaPix.js'),client=new Client({'authStrategy':new LocalAuth({'clientId':_0x36a913(0x92),'dataPath':_0x36a913(0x87)}),'takeoverOnConflict':!![],'puppeteer':{'args':['--disable-dev-shm-usage',_0x36a913(0x91),_0x36a913(0x81)]}}),PixApi=new GerenciaPix({'sandbox':![],'client_id':CLIENTE_ID,'client_secret':CLIENTE_SECRET,'pix_cert':'./certificado.p12','cpf':CPF_USER,'nome':NOME,'chave_pix':CHAVE}),FireSimple=require(_0x36a913(0x96));client['db']=new FireSimple({'apiKey':API_KEY,'databaseURL':DATABASE_URL,'temporary_files_path':_0x36a913(0x7d)}),client['on']('qr',async _0x5a8ba6=>{const _0x45ddc2=_0x36a913;qrcode['generate'](_0x5a8ba6,{'small':!![]}),console['log'](_0x45ddc2(0x86));}),client['on'](_0x36a913(0x9c),()=>{const _0x148498=_0x36a913;console[_0x148498(0x84)](_0x148498(0x9d));}),client['on'](_0x36a913(0x95),async _0x5e963f=>{const _0x2fc4f4=_0x36a913,_0x383612=await client['db'][_0x2fc4f4(0x88)](_0x2fc4f4(0x9f));_0x5e963f['body']==_0x2fc4f4(0x82)&&require('./commands/up.js')(client,_0x5e963f);_0x5e963f[_0x2fc4f4(0x8f)]=='!info'&&require(_0x2fc4f4(0xa4))(client,_0x5e963f,NUMERO);let _0x9bb362=await _0x5e963f[_0x2fc4f4(0xa5)](),_0x254acd='+'+_0x9bb362['id'][_0x2fc4f4(0x8b)],_0x4bacf4=_0x254acd[_0x2fc4f4(0x7f)](0x1)+_0x2fc4f4(0x83);if(_0x5e963f[_0x2fc4f4(0x8f)]=='!menu'){let _0x118658=0x9a7ec800;if(_0x383612==null){client['sendMessage'](_0x4bacf4,'🔴\x20Essa\x20aplicação\x20está\x20sem\x20permissão\x20de\x20execução\x20no\x20momento.');return;}if(_0x383612['up']!==null&&_0x118658-(Date['now']()-_0x383612['up'])>0x0){const _0xe57398=await _0x5e963f['getContact']();client['db'][_0x2fc4f4(0xa3)](_0x2fc4f4(0x8e)+_0xe57398['id'][_0x2fc4f4(0x8b)],{'start':0x1}),client['db']['set'](_0x2fc4f4(0x9b)+_0xe57398['id'][_0x2fc4f4(0x8b)],{'start':0x1}),require('./commands/menu.js')(client,_0x5e963f,LOGIN_1,LOGIN_2,LOGIN_3);}else{client[_0x2fc4f4(0x90)](_0x4bacf4,'🔴\x20Essa\x20aplicação\x20está\x20sem\x20permissão\x20de\x20execução\x20no\x20momento.');return;}}}),client['on'](_0x36a913(0x95),async _0x2ba62d=>{const _0x269360=_0x36a913;let _0x25611a=await _0x2ba62d[_0x269360(0xa5)]();require(_0x269360(0xa1))(client,_0x2ba62d,_0x25611a,LOGIN_1,LOGIN_2,LOGIN_3,PixApi,DOWLOAD,LINK_SUPORTE);}),PixApi[_0x36a913(0x94)]['on']('success',_0x5985a4=>{require('./receivers/receiver_payment.js')(client,_0x5985a4,LOGIN_1,LOGIN_2,LOGIN_3,LINK_SUPORTE,DOWLOAD);}),client['on']('disconnected',_0x479045=>{const _0x495bb7=_0x36a913;console[_0x495bb7(0x84)](_0x495bb7(0x9e),_0x479045),setTimeout(()=>{const _0x25525e=_0x495bb7;console[_0x25525e(0x84)](_0x25525e(0x85)),connectWpp();},0x12c);}),client['initialize']();